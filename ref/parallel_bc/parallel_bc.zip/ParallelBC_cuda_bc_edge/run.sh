./c-all-run.sh
./g-all-run.sh
